Gatling 3 Fundamentals
=========================

Course code for the Gatling Fundamentals Udemy course - updated for Gatling v3

https://www.udemy.com/gatling-fundamentals
