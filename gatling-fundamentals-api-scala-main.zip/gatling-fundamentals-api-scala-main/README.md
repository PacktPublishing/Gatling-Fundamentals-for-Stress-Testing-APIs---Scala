Gatling Fundamentals for API Testing - Scala Version - course code
=============================================

Supporting course code for my [Gatling Fundamentals for API Testing - Scala Version](https://www.udemy.com/course/gatling-fundamentals/) course on Udemy